﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITSSB
{
    public partial class SponserRunner : UserControl
    {
        public SponserRunner()
        {
            InitializeComponent();
            label1.SetBounds((this.Size.Width)/3, label1.Location.Y, label1.Size.Width, label1.Size.Height);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void SponserRunner_Load(object sender, EventArgs e)
        {

        }
    }
}
